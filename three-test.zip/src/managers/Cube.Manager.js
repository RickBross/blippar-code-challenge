import { Group } from 'three/build/three.module';

class CubeManager extends Group {
  constructor(props) {

    super(props)
  }
}

export default CubeManager;
